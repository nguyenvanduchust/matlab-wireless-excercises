%=======================================================================
% Laboratory exercises for the lecture "Mobile Radio Communications"
% Exercise 1.2
%=======================================================================

clear;          % clear all available variables
m_mu=0;         % mean value
sigma_mu=1;     % variance
n=1000000;      % length of the noise vector
x=-4:0.05:4;    % set x variable
p=(1/sqrt(2*pi)*sigma_mu)*exp(-(x-m_mu).^2/2*sigma_mu^2);
% calculate the Gaussian distributed PDF
check=trapz(x,p)
% the integration of P(x) for -4 <= x >= 4. must equal 1.
plot(x,p,'r');
hold on;

%***************************************************************
% Generation of a random vector, and calculate its distribution
%***************************************************************

y= randn(1,n);  
m = mean(y) 
% mean value of the process y
variance = std(y)^2 
% variance of the process y
x2=-4:0.1:4;
c=hist(y,x2);
% calculate the history of the process y
stem(x2,c/n/(x2(2)-x2(1)));
% the calculation "c/n/(x2(2)-x2(1))" is to change from the history 
% diagram to the PDF

title('Gaussian distributed PDF');
xlabel('X');
ylabel('P(X)');
legend('theoretical','experimental');
hold off;


%???????????????????????????????????????????????????????????????
% Quetion: explain the expression "c/n/(x2(2)-x2(1))" to change from 
% the history diagram to the PDF
%???????????????????????????????????????????????????????????????