%=======================================================================
% Laboratory simulation  of digital  mobile  communications
% Exercise 1.1: Calculation of the probability density function of 
% a Gaussian distributed random variable
%=======================================================================

t_a = 0.05;                     % Sampling interval
x=-4:t_a:4;                     % Set x variable
p=(1/sqrt(2*pi))*exp(-x.^2/2);  
% Calculate PDF of a Gaussian distributed random variable
check=trapz(x,p);               % Integration of p

% Remark: The integration of P(x) for -4 <= x >= 4. must be equal to 1.
plot(x,p);
title('\fontsize{12}PDF of a Gaussian distributed random variable');
xlabel('x','FontSize',12);
ylabel('P(x)','FontSize',12);