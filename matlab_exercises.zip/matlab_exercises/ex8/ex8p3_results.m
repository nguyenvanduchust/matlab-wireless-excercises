load ser_sufficientGL.am;

ser_sufficientGL_x = ser_sufficientGL(1,:);

ser_sufficientGL_y = ser_sufficientGL(2,:);

load ser_tvc.am;

ser_tvc_x = ser_tvc(1,:);

ser_tvc_y = ser_tvc(2,:);

semilogy(ser_sufficientGL_x,ser_sufficientGL_y,'bo');

hold on;

semilogy(ser_tvc_x,ser_tvc_y,'r*');

hold off;

legend('time-invariant channel, f_D =0','time-variant channel, f_D = 50 Hz');
xlabel('SNR in dB');

ylabel('SER');
