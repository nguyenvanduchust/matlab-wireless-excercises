load ser_sufficientGL.am;

ser_sufficientGL_x = ser_sufficientGL(1,:);

ser_sufficientGL_y = ser_sufficientGL(2,:);

load ser_withoutGL.am;

ser_withoutGL_x = ser_withoutGL(1,:);

ser_withoutGL_y = ser_withoutGL(2,:);

semilogy(ser_sufficientGL_x,ser_sufficientGL_y,'bo');

hold on;

semilogy(ser_withoutGL_x,ser_withoutGL_y,'r*');

hold off;

legend('G = 9','G = 0');
xlabel('SNR in dB');

ylabel('SER');
