clear;
k=3;
R_c=1/2;

% ::Bit Source::
meg=round(rand(1,5000));% the input bit stream


% ::Cnvolutional Coder::
conlen= 3; % constraintlength=k=1+v, v=number of shift registers
codegen=[7 5];  %codegenerator g(1)=(1,1,1)->7, g(2)=(1,0,1)->5
trellis=poly2trellis(conlen,codegen);
x=convenc(meg,trellis); % the coded bit stream

% ::QPSK Modulation::
for i=1:2:length(x)
    if x(i)==0 & x(i+1)==0
        S((i+1)/2)=exp(j*pi/4);
    elseif x(i)==0 & x(i+1)==1
        S((i+1)/2)=exp(j*3*pi/4);
    elseif x(i)==1 & x(i+1)==1
        S((i+1)/2)=exp(j*5*pi/4);
    elseif x(i)==1 & x(i+1)==0
        S((i+1)/2)=exp(j*7*pi/4);
    end
end
% S is the modulated complex signal




SNR_db=0:5;

for i=1:length(SNR_db)
    c(i)=cha2(SNR_db(i),S,meg,trellis);%cha2 will demodulate,decode and 
end                                    %calculate the number of errors in the 
                                       %received signal
BEP=c/length(meg);

save ex7_Res SNR_db BEP

semilogy(SNR_db,BEP,'.--')
hold on

SNR_db=0:8;
load ex5p1_Res
load ex6p1_Res
BEP2=c/length(x);
semilogy(SNR_db,BEP2,'r.--')
title('The bit error probability')
xlabel('SNR in db')
ylabel('P_b')
legend('P_b with coder','P_b without coder')
hold off