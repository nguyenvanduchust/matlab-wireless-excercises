clear;
%SNR_db=0:5;
load ex7_Res SNR_db BEP
figure(2)

semilogy(SNR_db,BEP,'*--')
hold on

load ex5p1_Res
load ex6p1_Res
BEP2=c/length(x);
SNR_db2=0:8;
semilogy(SNR_db2,BEP2,'r.--')
title('The bit error probability, Exerciese')
xlabel('SND in db')
ylabel('P_b')
legend('P_b with coder','P_b without coder')
axis([0 15 0.000001 1])
hold off