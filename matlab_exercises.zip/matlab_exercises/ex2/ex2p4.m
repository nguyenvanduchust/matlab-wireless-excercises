%=======================================================================
% Laboratory exercises for the lecture "Mobile Radio Communications"
% Exercise 2.4
%=======================================================================

k0=0;
k1=3;
k2=80;
k=k0;       %the rice factor k =s^2/2b_0
x=0:0.01:3; %the time interval in seconds
ohm_p=1;    %the total received power
%z=2.*x.*sqrt(k*(k+1)/ohm_p);
p_alpha=(k+1)/ohm_p.*exp(-k-((k+1).*x./ohm_p)).*besseli(0,(2*sqrt(k*(k+1).*x./ohm_p)));
plot(x,p_alpha)
hold on
k=k1;
p_alpha1=(k+1)/ohm_p.*exp(-k-((k+1).*x./ohm_p)).*besseli(0,(2*sqrt(k*(k+1).*x./ohm_p)));
plot(x,p_alpha1,'r.')
hold on
k=k2;
p_alpha2=(k+1)/ohm_p.*exp(-k-((k+1).*x./ohm_p)).*besseli(0,(2*sqrt(k*(k+1).*x./ohm_p)));
plot(x,p_alpha2,'g-.')
title('The non-central chi-square Distribution')
xlabel('x')
ylabel('p_{\alpha^2}(x)')
legend('k=0','k=1','k=80')
hold off
