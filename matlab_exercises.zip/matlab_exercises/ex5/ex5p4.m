clear;
load ex5p1_Res S

S1=zeros(1,3*length(S));

S1(1)=S(1);
for i=2:length(S)
    S1(2*i+i-2)=S(i);
end

T=1/270800;
f_s=3/T;
t=-3*T:0.1e-6:3*T;

beta=0.5;

p=(sin(pi*t/T)./(pi*t/T)).*(cos(beta*pi*t/T))./(1-(4*(beta^2)*(t.^2)/T^2));

fi = filter(p,1,S1);
fi