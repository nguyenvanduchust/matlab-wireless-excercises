clear;
beta1=0;
beta2=0.5;
beta3=1;

T=1/270800;
f_s=3/T;
t=-3*T:1/f_s:3*T;

beta=beta1;

p=(sin(pi*t/T)./(pi*t/T)).*(cos(beta*pi*t/T))./(1-(4*(beta^2)*(t.^2)/T^2));
plot(t,p)
hold on

beta=beta2;

p=(sin(pi*t/T)./(pi*t/T)).*(cos(beta*pi*t/T))./(1-(4*(beta^2)*(t.^2)/T^2));
plot(t,p,'r')
hold on

beta=beta3;

p=(sin(pi*t/T)./(pi*t/T)).*(cos(beta*pi*t/T))./(1-(4*(beta^2)*(t.^2)/T^2));
plot(t,p,'g')
hold off

title('The time -continuous impulse response')
xlabel('t')
ylabel('p(t)')
legend('\beta=0','\beta=0.5','\beta=1')