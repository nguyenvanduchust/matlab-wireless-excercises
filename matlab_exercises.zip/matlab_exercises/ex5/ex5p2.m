clear;
load ex5p1_Res S;

Es=var(S);

Eb=Es/2;
SNR_db=6;
N_0=Eb/10^(SNR_db/10);
N=sqrt(N_0/2)*(randn(size(S))+j*randn(size(S)));

R=S+N;
plot(R,'.')
hold on

plot(S,'r*')
hold on

t=0:0.01:2*pi;
plot(exp(j*t),'r--')
legend('S_m','S')
xlabel('I')
ylabel('Q')
title('The complex signal-space diagram of 4-QPSK')
hold off

figure(2);

SNR_db=10;
N_0=Eb/10^(SNR_db/10);
N=sqrt(N_0/2)*(randn(size(S))+j*randn(size(S)));


R=S+N;
plot(R,'.')
hold on

plot(S,'g*')
hold on

t=0:0.01:2*pi;
plot(exp(j*t),'r--')
legend('R_m','S')
xlabel('I')
ylabel('Q')
title('The complex signal-space diagram of 4-QPSK')
hold off

