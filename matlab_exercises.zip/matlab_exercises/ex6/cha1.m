function chann_1=cha1(SNR_db,gS_m,FS,x,S) %for ex6p3
Es=var(S);
Eb=Es/2;
N_0=Eb/10^(SNR_db/10);
N0=sqrt(N_0/2)*(randn(size(FS))+j*randn(size(FS)));
NFS=FS+N0;

for i=1:length(FS)/4
    for k=1:4
    d=abs(gS_m(4*i-3:4*i)-NFS((4*i-4+k)));
    
    md=min(d);
    if md==d(1);
        R(8*i-8+2*k-1)=0;
        R(8*i-8+2*k)=0;
    elseif md==d(2)
        R(8*i-8+2*k-1)=0;
        R(8*i-8+2*k)=1;
    elseif md==d(3)
        R(8*i-8+2*k-1)=1;
        R(8*i-8+2*k)=1;
    elseif md==d(4)
        R(8*i-8+2*k-1)=1;
        R(8*i-8+2*k)=0;
    end
end       
end

c=0;
for i=1:length(x)
    if R(i) ~= x(i);
        c=c+1;
    end
end
chann_1=c;