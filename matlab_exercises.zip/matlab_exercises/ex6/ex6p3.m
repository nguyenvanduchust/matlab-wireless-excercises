%==========================================================
% Matlab Exercises for mobile communications
% Exercise 6.3: digital communication over a fading channel
% Van Duc Nguyen, Agder College, Autumn 2004
%==========================================================

clear;
load ex5p1_Res;
S=S(1:20000);
x=x(1:40000);

%--------------------------------------
% Parameters for channel simulator
%--------------------------------------

f_m=91;     % maximum Doppler frequency
b=1/2;
N1=9;       % number of sinusoids
N2=N1+1;
    f1=f_m*sin(pi/2/N1*((1:N1)-1/2));
    c1=sqrt(2*b/N1)*ones(size(f1));

    th1=rand(size(f1))*2*pi;
    f2=f_m*sin(pi/2/N2*((1:N2)-1/2));
    c2=sqrt(2*b/N2)*ones(size(f2));

    th2=rand(size(f2))*2*pi;

f_s=270800; % sampling frequency in hertz
% T_sim=length(S)/f_s; %simulation time in seconds
% t=linspace(0,T_sim,length(S));
T_symb=1/f_s; %the symbol duration
%t=(0:length(S)-1)*T_symb+T_symb/2;

t=(0:length(S)-1)*T_symb;
g1=g(c1,f1,th1,t);
g2=g(c2,f2,th2,t);
g=g1+j*g2;

FS=g.*S;    % multiplying with fading channel 

%--------------------------------------------
% Prepairation of reference symbols
%--------------------------------------------

theta_m=[pi/4,3*pi/4,5*pi/4,7*pi/4];
S_m=exp(j*theta_m);
for i=1:length(S)/4
    gS_m(4*i-3:4*i)=S_m .*g(4*i-3:4*i);
end

SNR_db=0:5:30;
for i=1:length(SNR_db)
    c(i)=receiver(SNR_db(i),S_m,FS,x,S,g);
    %c(i)=cha1(SNR_db(i),gS_m,FS,x,S,g);
end

BEP=c/length(x);

save ex6p3_Res_4 BEP;

semilogy(SNR_db,BEP,'.--')
title('The bit error probability of fading channel')
xlabel('SNR in dB')
ylabel('P_b')
legend('P_b')