clear all;

M_ary = 2;

length_data = 1000;
source_data = randint(length_data,2);

symbols = bi2de(source_data);

qpsk_symbol = dmodce(symbols,1,1,'psk',M_ary);