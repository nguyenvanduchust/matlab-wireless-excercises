global d;
global md;
global R;