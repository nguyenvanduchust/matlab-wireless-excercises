function chann_1=receiver(SNR_db,S_m,FS,x,S,g) %for ex6p3
Es=var(S);
Eb=Es/2;
N_0=Eb/10^(SNR_db/10);
N0=sqrt(N_0/2)*(randn(size(FS))+j*randn(size(FS)));
NFS=(FS+N0)./g;

for i=1:length(FS)
    
    d=abs(S_m-NFS(i));
    
    md=min(d);
    if md==d(1);
        R(2*i-1)=0;
        R(2*i)=0;
    elseif md==d(2)
        R(2*i-1)=0;
        R(2*i)=1;
    elseif md==d(3)
        R(2*i-1)=1;
        R(2*i)=1;       
    elseif md==d(4)
        R(2*i-1)=1;
        R(2*i)=0;
    end
         
end

c=0;
for i=1:length(x)
    if R(i) ~= x(i);
        c=c+1;
    end
end
chann_1=c;