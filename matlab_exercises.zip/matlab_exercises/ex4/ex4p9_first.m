clear;
load ex4p9_Res_alpha t g1 g2 alpha

T_sim=1; %simulation time in seconds

R=3;
N=length(t);
level=0:0.05:R;
k=zeros(1,length(level));
for i=1:1:length(level)
    for n=1:1:N-1
        if alpha(n) > level(i) & alpha(n+1) <= level(i)
            k(i)=k(i)+1;
        end
    end
end

k_relativ=k./T_sim;

plot(level,k_relativ, '.')

legend('L_R')
xlabel('level')
ylabel('LCR')
title('Level Crossing Rate')

% save ex4p9_Res level k_relativ