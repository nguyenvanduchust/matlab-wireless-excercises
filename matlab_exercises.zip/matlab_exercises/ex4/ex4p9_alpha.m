clear;
load ex4p1_Res f1 f2 c1 c2 th1 th2

f_s=270800; % the carrier frequency in hertz
T_sim=1; %simulation time in seconds
t=0:1/f_s:T_sim;

g1=g(c1,f1,th1,t);
g2=g(c2,f2,th2,t);
alpha=abs(g1+j*g2);

save ex4p9_Res_alpha t g1 g2 alpha
