clear;
N1=9;
b=1;
load ex4p1_Res f1 f2 c1 c2 th1 th2

load ex4p9_Res level k_relativ

plot(level,k_relativ, '.')
hold on

for n=1:1:N1;
    ba(n)=(c1(n)*f1(n))^2;
end
beta=sum(ba)*2*pi^2;
R=0:0.05:3;
L_R2=sqrt(beta/(2*pi)).*(R/b).*exp(-R.^2/(2*b));
plot(R,L_R2,'r')

legend('L_R(R) of simulated channel','L_R(R) of simulation model')
xlabel('R')
ylabel('L_R(R)')
title('The Level Crossing Rate LCR')
hold off