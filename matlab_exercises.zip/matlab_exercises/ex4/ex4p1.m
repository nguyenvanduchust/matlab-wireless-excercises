%=======================================================================
% Laboratory exercises for the lecture "Mobile Radio Communications"
% Exercise 4.1
% Calculation of Doppler coefficients, discrete Doppler frequencies
% Doppler phases according to the method of exact Doppler spread (MEDS)
%=======================================================================

clear
f_m=91;     % Maximal Doppler frequency
b=1;        % Variance of inphase or quadrature component
N1=9;       % Number of sinusoids for the inphase component
N2=10;      % Number of sinuosoids for the quadrature component

for n=1:1:N1;
     c1(n)=sqrt(2*b/N1);
     f1(n)=f_m*sin(pi*(n-0.5)/(2*N1));
     th1(n)=2*pi*n/(N1+1); 
end

for n=1:1:N2;
     c2(n)=sqrt(2*b/N2);
     f2(n)=f_m*sin(pi*(n-0.5)/(2*N2));
     th2(n)=2*pi*n/(N2+1); 
     
end


save ex4p1_Res f1 f2 c1 c2 th1 th2
