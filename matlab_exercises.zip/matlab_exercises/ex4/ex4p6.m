%=======================================================================
% Exercise 4.6
%=======================================================================

clear;
f_m=91; % Maximum Doppler frequency
b=1;
N1=9;
tau_max = 0.08;
t_a = 0.001;

for n=1:N1;
    c1(n)=sqrt(2*b/N1);
    f1(n)=f_m*sin(pi*(n-0.5)/(2*N1));
    th1(n)=2*pi*n/(N1+1); 
end

tau=0:t_a:tau_max;
k=1:length(tau);
for n=1:N1
    x(n,k)=(c1(n)^2/2)*cos(2*pi*f1(n).*tau);
end
fay=sum(x);

tau_s=-tau_max:t_a:tau_max;
k=1:length(tau_s);
for n=1:N1
    xs(n,k)=(c1(n)^2/2)*cos(2*pi*f1(n).*tau_s);
end
phi_g1g1_theory=sum(xs);



plot(tau,fay);
hold on;
f_c=900e6;      %the carrier frequency in Hz
c_0=3e8;        %the speed of light in m/s
v=109.2e3/3600; %the mobile station's speed in m/s
f_m=v*f_c/c_0;  %the maximum doppler frequency
ohm_p=2;        %the total received power
t=0:0.001:tau_max; %the time interval in seconds
z=2*pi*f_m*t;
phi_gIgI=(ohm_p/2)*besselj(0,z); %the autocorrelation function
plot(tau,phi_gIgI,'r')

load ex4p5_Res;
N = length(phi_g1g1);
phi_g1g1_s = phi_g1g1(N/2:N/2+tau_max/t_a)

plot(tau,phi_g1g1_s,'k.')
title('The autocorrelation function (ACF) of the process g1')
xlabel('\tau in seconds')
ylabel('\phi_{g1g1}(\tau)')
legend('\phi_{g1g1}(\tau) Simulation model (Theory)','\phi_{g1g1}(\tau) Reference model','\phi_{g1g1}(\tau) Simulation')
hold off
