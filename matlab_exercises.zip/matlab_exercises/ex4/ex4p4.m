


clear
load ex4p1_Res f1 f2 c1 c2 th1 th2

f_s=50000;  % the carrier frequency in hertz
T_sim=20;   % simulation time in seconds
t=0:1/f_s:T_sim;

load ex4p4_Res g1 g alpha

g_mean=mean(g)
g_variance=var(g)
g1_mean=mean(g1)
g1_variance=var(g1)
alpha_mean=mean(alpha)
alpha_variance=var(alpha)
n=length(alpha);
x=0:0.1:3;  %the time interval in seconds
b=hist(alpha,x);

figure(1);
stem(x,b/n/(x(2)-x(1)))
hold on

k=0;        %the rice factor k =s^2/2b_0
ohm_p=2;    %the total received power
p_alpha=(2.*x.*(k+1)/ohm_p).*exp(-k-((k+1).*x.^2/ohm_p)).*besseli(0,(2.*x.*sqrt(k*(k+1)/ohm_p)));

plot(x,p_alpha,'r')
title('The PDF of alpha(x)')
xlabel('x')
ylabel('P_{\alpha}(x)')
legend('P_{\alpha}(x)','Rayleigh distribution (Theory)')


n1=length(g1);
x1=-4:0.1:4; %the time interval in seconds

figure(2);
c=hist(g1,x1);
stem(x1,c/n1/(x1(2)-x1(1)))
hold on
p=(1/sqrt(2*pi))*exp(-x1.^2/2);
plot(x1,p,'r')
title('The PDF of g1')
xlabel('x')
ylabel('P_{g1}(x)')
legend('P_{g1}(x)','Gaussian ditribution (Theory)')
hold off