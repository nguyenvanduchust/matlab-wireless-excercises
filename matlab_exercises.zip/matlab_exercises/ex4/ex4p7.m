load ex4p5_Res;

load ex4p6_Res;

%phi_g1g1=phi_g1g1(9920:10080);



s=fft(phi_g1g1);

s_theory = fft(phi_g1g1_theory);
f=(-length(s)/2:(length(s)/2)-1)/length(s)*f_s;

delta_f1 = f_s/length(s_theory);
f_theory = -f_s/2 : delta_f1 : f_s/2-delta_f1;


plot(f,fftshift(abs(s))/length(s),'b-');
%plot(f_a1,fftshift(abs(s))/length(s),'b-');
psd_simulation = fftshift(abs(s))/length(s);
psd_theory = fftshift(abs(s_theory))/length(s_theory);

hold on;
delta_f2 = f_s/length(s_theory);
f_a2 = -f_s/2 : delta_f2 : f_s/2-delta_f2;

%plot(f_a2,fftshift(abs(s_theory))/length(s_theory),'r.-');


hold off;
%plot(f,(abs(s))/length(s),'b-');
xlabel('f');
ylabel('PSD')
legend('Simulation', 'Theory')

save ex4p7_Res f f_theory psd_simulation psd_theory;