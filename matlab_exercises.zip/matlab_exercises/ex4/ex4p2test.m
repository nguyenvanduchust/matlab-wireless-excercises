%=======================================================================
% Laboratory exercises for the lecture "Mobile Radio Communications"
% Exercise 4.2
%=======================================================================
clear
f_m=91;
b=1;
N1=9;
N2=10;
for i=1:1:101;
t=(i-1)*0.01;
n1=1:1:N1;
c1=sqrt(2*b/N1);
f1=f_m*sin(pi*(n1-0.5)/(2*N1));
th1=2*pi.*n1/(N1+1);
g1(i)=sum(c1*cos(2*pi*f1*t+th1));

n2=1:1:N2;
c2=sqrt(2*b/N2);
f2=f_m*sin(pi*(n2-0.5)/(2*N2));
th2=2*pi.*n2/(N2+1);
g2(i)=sum(c2*cos(2*pi*f2*t+th2));
end
g=g1+j*g2;
x=0:0.01:1;
plot(x,g)
hold on

%alpha=abs(g1+j*g2);
%alpha_dB=20*log(alpha);
%plot(x,alpha_dB,'r')
