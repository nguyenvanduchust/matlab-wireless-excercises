clear;
load ex4p9_Res level k_relativ

plot(level,k_relativ, '.')

legend('L_R')
xlabel('level')
ylabel('LCR')
title('Level Crossing Rate')
