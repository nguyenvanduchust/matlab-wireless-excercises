clear;
f_m=91;
b=1;
N1=9;
for n=1:1:N1;
    c1(n)=sqrt(2*b/N1);
    f1(n)=f_m*sin(pi*(n-0.5)/(2*N1));
    th1(n)=2*pi*n/(N1+1); 
end

for n=1:1:N1;
    ba(n)=(c1(n)*f1(n))^2;
end
bata=sum(ba)*2*pi^2;
R=0:0.05:3;
L_R2=sqrt(bata/(2*pi)).*R.*exp(-R.^2./(2*b));
plot(R,L_R2,'r-')
hold on


ohm_p=2; %the total received power
rau=R./sqrt(ohm_p);
k=0; %the rice factor k =s^2/2b_0
LR_div_fm=sqrt(2*pi*(k+1)).*rau.*exp(-k-(k+1).*rau.^2).*besseli(0,(2.*rau.*sqrt(k*(k+1))));
L_R=LR_div_fm.*f_m;
plot(R,L_R,'b--')
hold off

title('The Level Crossing Rate LCR')
xlabel('R')
ylabel('L_R(R)')
legend('LCR of Simulation model','LCR of Rice processes')
hold off
