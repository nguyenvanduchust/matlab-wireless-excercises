clear;

load ex4p7_Res;
f_m=91;
b=1;
N1=9;
for n=1:1:N1;
    c1(n)=sqrt(2*b/N1);
    sg(n)= c1(n)^2/4;
    f1(n)=f_m*sin(pi*(n-0.5)/(2*N1));
    th1(n)=2*pi*n/(N1+1); 
end
stem(f1,sg)
hold on
stem(-f1,sg)

plot(f,psd_simulation,'r*')
plot(f_theory,psd_theory,'kx')
hold off

title('The power spectral density PSD')
xlabel('f')
ylabel('S_{gIgI}(f)')
legend('S_{gIgI}(f)')